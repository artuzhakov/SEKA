// useGameState.js - ФИНАЛЬНАЯ ВЕРСИЯ (ПОЛНОСТЬЮ ИСПРАВЛЕННАЯ)
import { ref, computed } from 'vue'
import { useWebSocket } from './useWebSocket'
import { useGameTimers } from './useGameTimers'

const globalGameState = ref(null)

export function useGameState(gameId) {
  const isLoading = ref(false)
  const error = ref(null)
  const gameState = globalGameState

  // Таймеры
  const {
    syncTimersFromBackend,
    turnTimeLeft,
    readyTimeLeft,
    revealTimeLeft,
    turnProgress,
    readyProgress,
    revealProgress,
    isTurnTimeCritical,
    isReadyTimeCritical,
    isRevealTimeCritical
  } = useGameTimers()

  const { subscribeToGame, isConnected } = useWebSocket()

  // Обновляем состояние игры
  const applyGameSnapshot = (newState) => {
    console.log('🔄 Game state updated:', newState)
    globalGameState.value = newState

    // Синхронизируем таймеры
    const phase = newState.game_phase || newState.status || null
    if (newState.timers) {
      syncTimersFromBackend(newState.timers, phase)
    }
  }

  // WebSocket
  const setupWebSocket = () => {
    if (!gameId) return

    subscribeToGame(gameId, {
      onGameStateUpdated: (data) => {
        console.log('🔄 WS: GameStateUpdated', data)
        updateFromWebSocket(data)
      },
      onPlayerAction: (data) => {
        console.log('🎯 WS: PlayerActionTaken', data)
        // Перезагружаем состояние после действия
        loadGameState()
      }
    })
  }

  // Загрузка состояния
  const loadGameState = async () => {
    if (!gameId) return

    isLoading.value = true
    error.value = null

    try {
      const response = await fetch(`/api/seka/games/${gameId}/state`)
      if (!response.ok) throw new Error('Ошибка загрузки игры')

      const data = await response.json()
      const state = data.game || data
      applyGameSnapshot(state)

      setupWebSocket()
    } catch (err) {
      error.value = err.message
    } finally {
      isLoading.value = false
    }
  }

  // Вычисляемые свойства
  const currentPlayer = computed(() => {
    const currentPlayerId = gameState.value?.current_player_id
    if (!currentPlayerId) return null
    
    return gameState.value?.players_list?.find(p => p.id === currentPlayerId) || null
  })

  const isCurrentPlayerTurn = computed(() => {
    return currentPlayer.value?.id === gameState.value?.current_player_id
  })

  const activePlayers = computed(() => {
    return gameState.value?.players_list?.filter(p => 
      p.status === 'active' || p.status === 'in_game'
    ) || []
  })

  const readyPlayersCount = computed(() => {
    return gameState.value?.players_list?.filter(p => p.is_ready).length || 0
  })

  const gameStatus = computed(() => {
    return gameState.value?.game_phase || gameState.value?.status || 'waiting'
  })

  const updateFromWebSocket = (data) => {
    if (data.game) {
      applyGameSnapshot(data.game)
    } else if (data.state) {
      applyGameSnapshot(data.state)
    } else {
      applyGameSnapshot(data)
    }
  }

  const joinGame = async () => {
    try {
      const response = await fetch(`/api/seka/games/${gameId}/join`, {
        method: 'POST'
      })
      if (!response.ok) throw new Error('Ошибка входа в игру')
      await loadGameState()
    } catch (err) {
      error.value = err.message
    }
  }

  // 🎯 ЗАГЛУШКИ ДЛЯ ОТСУТСТВУЮЩИХ СВОЙСТВ (пока не реализованы)
  const isTurnTransitioning = ref(false)
  const previousPlayer = ref(null)
  const currentPlayerActions = ref([])
  const revealState = ref({ 
    isActive: false, 
    participants: [], 
    winnerId: null, 
    loserId: null, 
    resolved: false 
  })
  const resetRevealState = () => {
    revealState.value = { 
      isActive: false, 
      participants: [], 
      winnerId: null, 
      loserId: null, 
      resolved: false 
    }
  }

  // Автозагрузка
  if (gameId) loadGameState()

  return {
    // Состояние
    gameState,
    isLoading,
    error,
    
    // Игроки
    currentPlayer,
    isCurrentPlayerTurn,
    activePlayers,
    readyPlayersCount,
    gameStatus,
    
    // Таймеры
    turnTimeLeft,
    readyTimeLeft,
    revealTimeLeft,
    turnProgress,
    readyProgress,
    revealProgress,
    isTurnTimeCritical,
    isReadyTimeCritical,
    isRevealTimeCritical,
    
    // 🎯 НОВЫЕ СВОЙСТВА (заглушки)
    isTurnTransitioning,
    previousPlayer,
    currentPlayerActions,
    revealState,
    resetRevealState,
    
    // Методы
    loadGameState,
    joinGame,
    isWebSocketConnected: isConnected
  }
}