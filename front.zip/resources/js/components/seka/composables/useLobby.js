// useLobby.js
import { ref, onMounted, onUnmounted } from 'vue'

export function useLobby() {
  const tables = ref([])
  const isLoading = ref(false)
  const error = ref(null)

  // Загрузка списка столов
  const loadTables = async () => {
    isLoading.value = true
    error.value = null
    
    try {
      const response = await fetch('/api/seka/games')
      if (!response.ok) throw new Error('Ошибка загрузки столов')
      
      const data = await response.json()
      tables.value = data.games || data
      
      console.log('🎯 Loaded tables:', tables.value)
    } catch (err) {
      error.value = err.message
      console.error('❌ Failed to load tables:', err)
    } finally {
      isLoading.value = false
    }
  }

  // WebSocket для реального обновления
  const setupWebSocket = () => {
    // Здесь будет подписка на обновления столов
    console.log('🔌 Lobby WebSocket setup - to be implemented')
  }

  // Автообновление каждые 5 секунд (временное решение)
  let refreshInterval = null
  
  const startAutoRefresh = () => {
    refreshInterval = setInterval(loadTables, 5000)
  }
  
  const stopAutoRefresh = () => {
    if (refreshInterval) {
      clearInterval(refreshInterval)
      refreshInterval = null
    }
  }

  onMounted(() => {
    loadTables()
    startAutoRefresh()
  })

  onUnmounted(() => {
    stopAutoRefresh()
  })

  return {
    tables,
    isLoading,
    error,
    loadTables,
    refreshTables: loadTables
  }
}