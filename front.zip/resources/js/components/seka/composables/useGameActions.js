// useGameActions.js - ПОЛНАЯ РЕАЛИЗАЦИЯ
import { ref } from 'vue'

const getCsrfToken = () => {
  return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
}

export function useGameActions(gameId) {
  const isActionLoading = ref(false)
  const lastError = ref(null)
  const lastSuccess = ref(null)

  const performAction = async (action, amount = null) => {
    isActionLoading.value = true
    lastError.value = null
    lastSuccess.value = null

    try {
      const csrfToken = getCsrfToken()
      if (!csrfToken) {
        throw new Error('CSRF token not found')
      }

      // 🎯 ФОРМИРУЕМ ПРАВИЛЬНЫЙ PAYLOAD ДЛЯ API
      const payload = { action }
      
      // Добавляем amount только для действий, которые его требуют
      const actionsWithAmount = ['raise', 'dark', 'call', 'reveal']
      if (actionsWithAmount.includes(action) && amount !== null) {
        payload.amount = amount
      }

      console.log('🎯 Sending action to API:', { action, amount, payload })

      const response = await fetch(`/api/seka/games/${gameId}/action`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': csrfToken,
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`)
      }

      const result = await response.json()
      lastSuccess.value = { action, amount, timestamp: Date.now() }
      
      console.log('✅ Action performed successfully:', { action, amount, result })
      
      return result

    } catch (error) {
      lastError.value = {
        message: error.message,
        action,
        amount,
        timestamp: Date.now()
      }
      console.error('❌ Action failed:', error)
      throw error
    } finally {
      isActionLoading.value = false
    }
  }

  // 🎯 СПЕЦИАЛИЗИРОВАННЫЕ МЕТОДЫ ДЛЯ КОНКРЕТНЫХ ДЕЙСТВИЙ
  const call = async () => {
    return performAction('call')
  }

  const raise = async (amount) => {
    if (!amount || amount <= 0) {
      throw new Error('Amount must be positive for raise')
    }
    return performAction('raise', amount)
  }

  const fold = async () => {
    return performAction('fold')
  }

  const check = async () => {
    return performAction('check')
  }

  const dark = async (amount = null) => {
    return performAction('dark', amount)
  }

  const open = async () => {
    return performAction('open')
  }

  const reveal = async () => {
    return performAction('reveal')
  }

  const markPlayerReady = async () => {
    return performAction('ready')
  }

  // 🎯 ОЧИСТКА СОСТОЯНИЙ
  const clearError = () => {
    lastError.value = null
  }

  const clearSuccess = () => {
    lastSuccess.value = null
  }

  return {
    // Основной метод
    performAction,
    
    // Специализированные методы
    call,
    raise,
    fold,
    check,
    dark,
    open,
    reveal,
    markPlayerReady,
    
    // Состояния
    isActionLoading,
    lastError,
    lastSuccess,
    
    // Очистка
    clearError,
    clearSuccess
  }
}